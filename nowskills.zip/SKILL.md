---
name: now-mcp-cards
description: This skill should be used when the user wants to "create a tag card", "add a content card", "make a folder", "move a card", "delete a card", or interact with the Now app's database using the Now MCP server tools.
version: 0.1.0
---

# Now App MCP Card Management

This skill provides instructions for managing cards, tags, and folders in the Now app via its local MCP server. 

## About the Now App MCP Server

The Now app exposes a set of MCP tools allowing AI agents to directly manipulate its SQLite database. Changes made via these tools emit a background signal that automatically refreshes the Tauri UI within 2 seconds.

**Available Tools:**
- `create_card`: Create new cards (tags, content, folders)
- `update_card`: Update the content/title of existing cards
- `delete_card`: Delete cards by ID
- `move_card`: Move cards to different tags, categories, or parent IDs
- `list_cards`: View existing cards
- `list_libraries` / `get_active_library` / `set_active_library`: Manage library context

---

## 1. Creating Cards (`create_card`)

To create a card, invoke the `create_card` tool. The tool will return the newly created card's ID and details.

### Creating a Tag Card (标签卡片)
Set `type` to `"TAGS"`. Provide a comma-separated list of tags in the `content` field.
```json
{
  "title": "My New Tag",
  "content": "Tag1, Tag2, Tag3",
  "category": "🎙配音",
  "type": "TAGS",
  "parentId": "optional-parent-uuid"
}
```

### Creating a Content/Document Card (内容卡片)
Set `type` to `"DOCUMENT"` (for rich text) or `"TEXT"` (for plain text).
```json
{
  "title": "Document Title",
  "content": "The actual body of the document...",
  "category": "🎙配音",
  "type": "DOCUMENT",
  "parentId": "optional-parent-uuid"
}
```

### Creating a Folder (文件夹)
Set `type` to `"FOLDER"`. The backend will automatically prefix the title with a folder emoji `📂` and set the type to `DOCUMENT` under the hood.
```json
{
  "title": "My Projects",
  "category": "🎙配音",
  "type": "FOLDER",
  "parentId": "optional-parent-uuid"
}
```

---

## 2. Moving & Organizing Cards (`move_card`)

To move a card to a new tag, category, or parent, use the `move_card` tool.
You must provide the `id` of the card.
Optional fields: `parent_id`, `category`, and `tags` (an array of strings).

**Example:**
```json
{
  "id": "card-uuid-here",
  "tags": ["New Tag Name"],
  "category": "🎙配音",
  "parent_id": "new-parent-uuid"
}
```

---

## 3. Modifying Cards (`update_card`)

To modify the title or content of an existing card, use `update_card`.

**Example:**
```json
{
  "id": "card-uuid-here",
  "title": "Updated Title",
  "content": "Updated content..."
}
```

---

## 4. Deleting Cards (`delete_card`)

To delete a card, simply provide its `id` to the `delete_card` tool.

**Example:**
```json
{
  "id": "card-uuid-here"
}
```

---

## 5. Querying Cards (`list_cards`)

To see what cards already exist (e.g. to find a specific ID or category name), use `list_cards`.
Optional fields: `limit` (default 10), `category`, `parentId`.

**Example:**
```json
{
  "limit": 5,
  "category": "🎙配音"
}
```
*Note: To list top-level items only (not in any folder), set `parentId` to `"null"`.*

---

## 6. Batch Updating Tags (`batch_update_tags`)

To rename or remove a tag across all cards in the current library, use `batch_update_tags`.
Provide `oldTag` and optionally `newTag` (if omitted, the old tag is simply removed).

**Example:**
```json
{
  "oldTag": "Old Name",
  "newTag": "New Name"
}
```

---

## Important Rules & Best Practices

1. **Category Exact Match**: The `category` parameter must perfectly match the existing categories in the app, including any emojis (e.g., `"🎙配音"` instead of just `"配音"`). If you're unsure, fetch existing cards to check the category naming conventions.
2. **Library Context**: By default, the MCP server respects the `active_library_id` of the app. Ensure you are targeting the correct context (verify via `get_active_library` and change via `set_active_library` if necessary). The `list_libraries` tool will list all available libraries.
3. **Auto-Refresh**: The Now app automatically detects MCP changes via a `mcp_signal.json` watcher and refreshes the UI within 2 seconds. **Do not** instruct the user to refresh the UI manually or switch tabs.
4. **Parent-Child Hierarchy**: When placing an item inside a folder or under a specific tag card, supply the parent card's ID as the `parentId` (in `create_card`) or `parent_id` (in `move_card`).
